<!doctype html>
<html>
<?php include( "header.php") ?>
<body class="text-center">
	<link rel="stylesheet" href="css/login/style.css">
	<form class="form-signin" action="/magnani-inspections">
		<div class="mx-auto" style="width:80px;height:72px;background-color:black;border-radius:5px">
			<img  src="img\Logo-M-branca-300x300.png" alt="" width="72" height="72">
		</div>
		<h1 class="h3 mb-3 mt-3 font-weight-normal">Magnani Inspections</h1>
		</div>
		<button class="btn btn-lg btn-primary btn-block">Entrar</button>
	</form>
</body>
</html>