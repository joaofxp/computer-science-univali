<?php include("pgsql.php"); ?>

<head>
  <title>Magnani Inspections</title>

  <meta charset="utf-8">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">

  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,400,600,700">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  

  <!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,300,700"> -->
  <!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->
  <!-- <link rel="stylesheet" href="css/ionicons.min.css">
  <link rel="stylesheet" href="js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/editorhtml.css"> -->
  <!-- Plugin CSS -->
  <!-- <link rel="stylesheet" href="js/plugins/morris/morris.css">
  <link rel="stylesheet" href="js/plugins/icheck/skins/minimal/blue.css">
  <link rel="stylesheet" href="js/plugins/select2/select2.css">
  <link rel="stylesheet" href="js/plugins/fullcalendar/fullcalendar.css"> -->
  <!-- <link rel="stylesheet" href="js/plugins/fileupload/bootstrap-fileupload.css"> -->
  <!-- <link rel="stylesheet" href="js/plugins/magnific/magnific-popup.css"> -->
  <!-- App CSS -->
  <!-- <link rel="stylesheet" href="css/target-admin.css"> -->
  <!-- <link rel="stylesheet" href="css/custom.css"> -->
  <!-- <link rel="stylesheet" href="css/jquery.autocomplete.css"> -->

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
  <![endif]-->
</head>