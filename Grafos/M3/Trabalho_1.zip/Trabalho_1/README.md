Fazer um programa que receba uma tabela de atividades, duração e precedentes e monte o grafo de PERT/CPM, identificando o caminho crítico e as folgas nas atividades.

Utilizar a notação de aula, com tempo máximo e mínimo para inicio e fim das atividades, com a atividade sendo representado pelos vértices do grafo, conforme exemplo a seguir.

O trabalho deverá ser apresentado no dia da entrega, explicando como ele foi feito e demonstrando seu funcionamento.