enviarMensagem = () => {
    const mensagem = document.getElementById("mensagemEnviar").value;

    (async () => {
        const rawResponse = await fetch("http://127.0.0.1:3000/task", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                mensagemPost: mensagem,
            }),
        });
        const { message: retorno } = await rawResponse.json();

        document.getElementById("areaDeMensagens").innerText = retorno;
    })();
};
