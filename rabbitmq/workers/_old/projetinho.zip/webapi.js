//webapi.js
const express = require("express");
const cors = require("cors");

const queue = require("./queue");

const app = express();
app.use(express.urlencoded({ extended: true }));

app.use(cors());
app.use(express.json());

const router = express.Router();

router.post("/task", (req, res) => {
    console.log("recebeu -> " + req.body);
    queue.sendToQueue("fila1", req.body);
    res.json({ message: "Processando sua mensagem..." });
});

app.use("/", router);

app.listen(3000);
